/*
 * RotationTesting.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "RotationTesting".
 *
 * Model version              : 1.6
 * Simulink Coder version : 9.9 (R2023a) 19-Nov-2022
 * C source code generated on : Wed Oct 11 01:28:43 2023
 *
 * Target selection: ert.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "RotationTesting.h"
#include "rtwtypes.h"
#include "RotationTesting_types.h"
#include "RotationTesting_private.h"
#include <math.h>
#include <string.h>

/* Named constants for Chart: '<Root>/Chart' */
#define RotationTest_IN_NO_ACTIVE_CHILD ((uint8_T)0U)
#define RotationTesting_IN_Left        ((uint8_T)1U)
#define RotationTesting_IN_Pause       ((uint8_T)2U)
#define RotationTesting_IN_Right       ((uint8_T)3U)

/* Block signals (default storage) */
B_RotationTesting_T RotationTesting_B;

/* Block states (default storage) */
DW_RotationTesting_T RotationTesting_DW;

/* Real-time model */
static RT_MODEL_RotationTesting_T RotationTesting_M_;
RT_MODEL_RotationTesting_T *const RotationTesting_M = &RotationTesting_M_;
uint32_T plook_u32d_binckan(real_T u, const real_T bp[], uint32_T maxIndex)
{
  uint32_T bpIndex;

  /* Prelookup - Index only
     Index Search method: 'binary'
     Interpolation method: 'Use nearest'
     Extrapolation method: 'Clip'
     Use previous index: 'off'
     Use last breakpoint for index at or above upper limit: 'on'
     Remove protection against out-of-range input in generated code: 'off'
   */
  if (u <= bp[0U]) {
    bpIndex = 0U;
  } else if (u < bp[maxIndex]) {
    bpIndex = binsearch_u32d(u, bp, maxIndex >> 1U, maxIndex);
    if ((bpIndex < maxIndex) && (bp[bpIndex + 1U] - u <= u - bp[bpIndex])) {
      bpIndex++;
    }
  } else {
    bpIndex = maxIndex;
  }

  return bpIndex;
}

uint32_T binsearch_u32d(real_T u, const real_T bp[], uint32_T startIndex,
  uint32_T maxIndex)
{
  uint32_T bpIdx;
  uint32_T bpIndex;
  uint32_T iRght;

  /* Binary Search */
  bpIdx = startIndex;
  bpIndex = 0U;
  iRght = maxIndex;
  while (iRght - bpIndex > 1U) {
    if (u < bp[bpIdx]) {
      iRght = bpIdx;
    } else {
      bpIndex = bpIdx;
    }

    bpIdx = (iRght + bpIndex) >> 1U;
  }

  return bpIndex;
}

real_T rt_roundd_snf(real_T u)
{
  real_T y;
  if (fabs(u) < 4.503599627370496E+15) {
    if (u >= 0.5) {
      y = floor(u + 0.5);
    } else if (u > -0.5) {
      y = u * 0.0;
    } else {
      y = ceil(u - 0.5);
    }
  } else {
    y = u;
  }

  return y;
}

/* Model step function */
void RotationTesting_step(void)
{
  codertarget_arduinobase_int_l_T *obj_0;
  codertarget_arduinobase_inter_T *obj;
  real_T rtb_LeftPWM;
  real_T rtb_Switch1;
  real_T rtb_w;
  real_T tmp;
  real_T tmp_0;
  uint16_T b_varargout_1;
  uint16_T b_varargout_1_0;
  uint8_T tmp_1;

  /* MATLABSystem: '<Root>/Analog Input5' */
  if (RotationTesting_DW.obj_b.SampleTime !=
      RotationTesting_P.AnalogInput5_SampleTime) {
    RotationTesting_DW.obj_b.SampleTime =
      RotationTesting_P.AnalogInput5_SampleTime;
  }

  obj = &RotationTesting_DW.obj_b;
  obj->AnalogInDriverObj.MW_ANALOGIN_HANDLE = MW_AnalogIn_GetHandle(17U);
  RotationTesting_B.datatype_id = MW_ANALOGIN_UINT16;
  MW_AnalogInSingle_ReadResult
    (RotationTesting_DW.obj_b.AnalogInDriverObj.MW_ANALOGIN_HANDLE,
     &b_varargout_1, RotationTesting_B.datatype_id);

  /* MATLABSystem: '<Root>/Analog Input6' */
  if (RotationTesting_DW.obj.SampleTime !=
      RotationTesting_P.AnalogInput6_SampleTime) {
    RotationTesting_DW.obj.SampleTime =
      RotationTesting_P.AnalogInput6_SampleTime;
  }

  obj = &RotationTesting_DW.obj;
  obj->AnalogInDriverObj.MW_ANALOGIN_HANDLE = MW_AnalogIn_GetHandle(20U);
  RotationTesting_B.datatype_id = MW_ANALOGIN_UINT16;
  MW_AnalogInSingle_ReadResult
    (RotationTesting_DW.obj.AnalogInDriverObj.MW_ANALOGIN_HANDLE,
     &b_varargout_1_0, RotationTesting_B.datatype_id);

  /* Chart: '<Root>/Chart' incorporates:
   *  MATLABSystem: '<Root>/Analog Input5'
   *  MATLABSystem: '<Root>/Analog Input6'
   */
  if (RotationTesting_DW.is_active_c3_RotationTesting == 0U) {
    RotationTesting_DW.is_active_c3_RotationTesting = 1U;
    RotationTesting_DW.is_c3_RotationTesting = RotationTesting_IN_Pause;
    rtb_w = 0.0;
  } else {
    switch (RotationTesting_DW.is_c3_RotationTesting) {
     case RotationTesting_IN_Left:
      rtb_w = 0.8;
      if (b_varargout_1_0 < 1) {
        RotationTesting_DW.is_c3_RotationTesting = RotationTesting_IN_Pause;
        rtb_w = 0.0;
      }
      break;

     case RotationTesting_IN_Pause:
      rtb_w = 0.0;
      if (b_varargout_1_0 > 2) {
        RotationTesting_DW.is_c3_RotationTesting = RotationTesting_IN_Left;
        rtb_w = 0.8;
      } else if (b_varargout_1 > 2) {
        RotationTesting_DW.is_c3_RotationTesting = RotationTesting_IN_Right;
        rtb_w = -0.8;
      }
      break;

     default:
      /* case IN_Right: */
      rtb_w = -0.8;
      if (b_varargout_1 < 1) {
        RotationTesting_DW.is_c3_RotationTesting = RotationTesting_IN_Pause;
        rtb_w = 0.0;
      }
      break;
    }
  }

  /* End of Chart: '<Root>/Chart' */

  /* Gain: '<S3>/vtow' */
  tmp = 1.0 / RotationTesting_P.wheelR;

  /* Lookup_n-D: '<S2>/Left Motor LUT' incorporates:
   *  Constant: '<Root>/Constant'
   *  Gain: '<S3>/change parameters'
   *  Gain: '<S3>/vtow'
   *  SignalConversion generated from: '<S3>/change parameters'
   */
  rtb_LeftPWM = RotationTesting_P.InputPWM[plook_u32d_binckan
    ((RotationTesting_P.changeparameters_Gain[0] *
      RotationTesting_P.Constant_Value_e +
      RotationTesting_P.changeparameters_Gain[2] * rtb_w) * tmp,
     RotationTesting_P.WheelSpeed, 172U)];

  /* Switch: '<S2>/Switch1' incorporates:
   *  Constant: '<S2>/Constant2'
   *  Constant: '<S2>/Constant3'
   */
  if (rtb_LeftPWM > RotationTesting_P.Switch1_Threshold) {
    rtb_Switch1 = RotationTesting_P.Constant3_Value;
  } else {
    rtb_Switch1 = RotationTesting_P.Constant2_Value;
  }

  /* End of Switch: '<S2>/Switch1' */

  /* MATLABSystem: '<S2>/Digital Output4' */
  tmp_0 = rt_roundd_snf(rtb_Switch1);
  if (tmp_0 < 256.0) {
    if (tmp_0 >= 0.0) {
      tmp_1 = (uint8_T)tmp_0;
    } else {
      tmp_1 = 0U;
    }
  } else {
    tmp_1 = MAX_uint8_T;
  }

  writeDigitalPin(13, tmp_1);

  /* End of MATLABSystem: '<S2>/Digital Output4' */

  /* MATLABSystem: '<S2>/Digital Output6' incorporates:
   *  Logic: '<S2>/NOT1'
   */
  writeDigitalPin(12, (uint8_T)!(rtb_Switch1 != 0.0));

  /* MATLABSystem: '<S2>/PWM' */
  obj_0 = &RotationTesting_DW.obj_l;
  obj_0->PWMDriverObj.MW_PWM_HANDLE = MW_PWM_GetHandle(9U);
  if (!(rtb_LeftPWM <= 255.0)) {
    rtb_LeftPWM = 255.0;
  }

  if (!(rtb_LeftPWM >= 0.0)) {
    rtb_LeftPWM = 0.0;
  }

  MW_PWM_SetDutyCycle(RotationTesting_DW.obj_l.PWMDriverObj.MW_PWM_HANDLE,
                      rtb_LeftPWM);

  /* End of MATLABSystem: '<S2>/PWM' */

  /* Lookup_n-D: '<S2>/Right Motor LUT' incorporates:
   *  Constant: '<Root>/Constant'
   *  Gain: '<S3>/change parameters'
   *  Gain: '<S3>/vtow'
   *  SignalConversion generated from: '<S3>/change parameters'
   */
  rtb_w = RotationTesting_P.InputPWM[plook_u32d_binckan
    ((RotationTesting_P.changeparameters_Gain[1] *
      RotationTesting_P.Constant_Value_e +
      RotationTesting_P.changeparameters_Gain[3] * rtb_w) * tmp,
     RotationTesting_P.WheelSpeed, 172U)];

  /* Switch: '<S2>/Switch' incorporates:
   *  Constant: '<S2>/Constant'
   *  Constant: '<S2>/Constant1'
   */
  if (rtb_w > RotationTesting_P.Switch_Threshold) {
    rtb_LeftPWM = RotationTesting_P.Constant1_Value;
  } else {
    rtb_LeftPWM = RotationTesting_P.Constant_Value;
  }

  /* End of Switch: '<S2>/Switch' */

  /* MATLABSystem: '<S2>/Digital Output1' */
  tmp = rt_roundd_snf(rtb_LeftPWM);
  if (tmp < 256.0) {
    if (tmp >= 0.0) {
      tmp_1 = (uint8_T)tmp;
    } else {
      tmp_1 = 0U;
    }
  } else {
    tmp_1 = MAX_uint8_T;
  }

  writeDigitalPin(8, tmp_1);

  /* End of MATLABSystem: '<S2>/Digital Output1' */

  /* MATLABSystem: '<S2>/Digital Output3' incorporates:
   *  Logic: '<S2>/NOT'
   */
  writeDigitalPin(11, (uint8_T)!(rtb_LeftPWM != 0.0));

  /* MATLABSystem: '<S2>/PWM1' */
  obj_0 = &RotationTesting_DW.obj_k;
  obj_0->PWMDriverObj.MW_PWM_HANDLE = MW_PWM_GetHandle(10U);
  if (!(rtb_w <= 255.0)) {
    rtb_w = 255.0;
  }

  if (!(rtb_w >= 0.0)) {
    rtb_w = 0.0;
  }

  MW_PWM_SetDutyCycle(RotationTesting_DW.obj_k.PWMDriverObj.MW_PWM_HANDLE, rtb_w);

  /* End of MATLABSystem: '<S2>/PWM1' */
}

/* Model initialize function */
void RotationTesting_initialize(void)
{
  /* Registration code */

  /* initialize error status */
  rtmSetErrorStatus(RotationTesting_M, (NULL));

  /* states (dwork) */
  (void) memset((void *)&RotationTesting_DW, 0,
                sizeof(DW_RotationTesting_T));

  {
    codertarget_arduinobase_int_l_T *obj_0;
    codertarget_arduinobase_inter_T *obj;

    /* Start for MATLABSystem: '<Root>/Analog Input5' */
    RotationTesting_DW.obj_b.matlabCodegenIsDeleted = false;
    RotationTesting_DW.objisempty_c = true;
    RotationTesting_DW.obj_b.SampleTime =
      RotationTesting_P.AnalogInput5_SampleTime;
    obj = &RotationTesting_DW.obj_b;
    RotationTesting_DW.obj_b.isInitialized = 1;
    obj->AnalogInDriverObj.MW_ANALOGIN_HANDLE = MW_AnalogInSingle_Open(17U);
    RotationTesting_DW.obj_b.isSetupComplete = true;

    /* Start for MATLABSystem: '<Root>/Analog Input6' */
    RotationTesting_DW.obj.matlabCodegenIsDeleted = false;
    RotationTesting_DW.objisempty_g = true;
    RotationTesting_DW.obj.SampleTime =
      RotationTesting_P.AnalogInput6_SampleTime;
    obj = &RotationTesting_DW.obj;
    RotationTesting_DW.obj.isInitialized = 1;
    obj->AnalogInDriverObj.MW_ANALOGIN_HANDLE = MW_AnalogInSingle_Open(20U);
    RotationTesting_DW.obj.isSetupComplete = true;

    /* Start for MATLABSystem: '<S2>/Digital Output4' */
    RotationTesting_DW.obj_n.matlabCodegenIsDeleted = false;
    RotationTesting_DW.objisempty_jg = true;
    RotationTesting_DW.obj_n.isInitialized = 1;
    digitalIOSetup(13, 1);
    RotationTesting_DW.obj_n.isSetupComplete = true;

    /* Start for MATLABSystem: '<S2>/Digital Output6' */
    RotationTesting_DW.obj_j.matlabCodegenIsDeleted = false;
    RotationTesting_DW.objisempty_j = true;
    RotationTesting_DW.obj_j.isInitialized = 1;
    digitalIOSetup(12, 1);
    RotationTesting_DW.obj_j.isSetupComplete = true;

    /* Start for MATLABSystem: '<S2>/PWM' */
    RotationTesting_DW.obj_l.matlabCodegenIsDeleted = false;
    RotationTesting_DW.objisempty_d = true;
    obj_0 = &RotationTesting_DW.obj_l;
    RotationTesting_DW.obj_l.isInitialized = 1;
    obj_0->PWMDriverObj.MW_PWM_HANDLE = MW_PWM_Open(9U, 0.0, 0.0);
    RotationTesting_DW.obj_l.isSetupComplete = true;

    /* Start for MATLABSystem: '<S2>/Digital Output1' */
    RotationTesting_DW.obj_ib.matlabCodegenIsDeleted = false;
    RotationTesting_DW.objisempty_h = true;
    RotationTesting_DW.obj_ib.isInitialized = 1;
    digitalIOSetup(8, 1);
    RotationTesting_DW.obj_ib.isSetupComplete = true;

    /* Start for MATLABSystem: '<S2>/Digital Output3' */
    RotationTesting_DW.obj_i.matlabCodegenIsDeleted = false;
    RotationTesting_DW.objisempty_b = true;
    RotationTesting_DW.obj_i.isInitialized = 1;
    digitalIOSetup(11, 1);
    RotationTesting_DW.obj_i.isSetupComplete = true;

    /* Start for MATLABSystem: '<S2>/PWM1' */
    RotationTesting_DW.obj_k.matlabCodegenIsDeleted = false;
    RotationTesting_DW.objisempty = true;
    obj_0 = &RotationTesting_DW.obj_k;
    RotationTesting_DW.obj_k.isInitialized = 1;
    obj_0->PWMDriverObj.MW_PWM_HANDLE = MW_PWM_Open(10U, 0.0, 0.0);
    RotationTesting_DW.obj_k.isSetupComplete = true;
  }

  /* SystemInitialize for Chart: '<Root>/Chart' */
  RotationTesting_DW.is_active_c3_RotationTesting = 0U;
  RotationTesting_DW.is_c3_RotationTesting = RotationTest_IN_NO_ACTIVE_CHILD;
}

/* Model terminate function */
void RotationTesting_terminate(void)
{
  codertarget_arduinobase_int_l_T *obj_0;
  codertarget_arduinobase_inter_T *obj;

  /* Terminate for MATLABSystem: '<Root>/Analog Input5' */
  obj = &RotationTesting_DW.obj_b;
  if (!RotationTesting_DW.obj_b.matlabCodegenIsDeleted) {
    RotationTesting_DW.obj_b.matlabCodegenIsDeleted = true;
    if ((RotationTesting_DW.obj_b.isInitialized == 1) &&
        RotationTesting_DW.obj_b.isSetupComplete) {
      obj->AnalogInDriverObj.MW_ANALOGIN_HANDLE = MW_AnalogIn_GetHandle(17U);
      MW_AnalogIn_Close
        (RotationTesting_DW.obj_b.AnalogInDriverObj.MW_ANALOGIN_HANDLE);
    }
  }

  /* End of Terminate for MATLABSystem: '<Root>/Analog Input5' */

  /* Terminate for MATLABSystem: '<Root>/Analog Input6' */
  obj = &RotationTesting_DW.obj;
  if (!RotationTesting_DW.obj.matlabCodegenIsDeleted) {
    RotationTesting_DW.obj.matlabCodegenIsDeleted = true;
    if ((RotationTesting_DW.obj.isInitialized == 1) &&
        RotationTesting_DW.obj.isSetupComplete) {
      obj->AnalogInDriverObj.MW_ANALOGIN_HANDLE = MW_AnalogIn_GetHandle(20U);
      MW_AnalogIn_Close
        (RotationTesting_DW.obj.AnalogInDriverObj.MW_ANALOGIN_HANDLE);
    }
  }

  /* End of Terminate for MATLABSystem: '<Root>/Analog Input6' */

  /* Terminate for MATLABSystem: '<S2>/Digital Output4' */
  if (!RotationTesting_DW.obj_n.matlabCodegenIsDeleted) {
    RotationTesting_DW.obj_n.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<S2>/Digital Output4' */

  /* Terminate for MATLABSystem: '<S2>/Digital Output6' */
  if (!RotationTesting_DW.obj_j.matlabCodegenIsDeleted) {
    RotationTesting_DW.obj_j.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<S2>/Digital Output6' */

  /* Terminate for MATLABSystem: '<S2>/PWM' */
  obj_0 = &RotationTesting_DW.obj_l;
  if (!RotationTesting_DW.obj_l.matlabCodegenIsDeleted) {
    RotationTesting_DW.obj_l.matlabCodegenIsDeleted = true;
    if ((RotationTesting_DW.obj_l.isInitialized == 1) &&
        RotationTesting_DW.obj_l.isSetupComplete) {
      obj_0->PWMDriverObj.MW_PWM_HANDLE = MW_PWM_GetHandle(9U);
      MW_PWM_SetDutyCycle(RotationTesting_DW.obj_l.PWMDriverObj.MW_PWM_HANDLE,
                          0.0);
      obj_0->PWMDriverObj.MW_PWM_HANDLE = MW_PWM_GetHandle(9U);
      MW_PWM_Close(RotationTesting_DW.obj_l.PWMDriverObj.MW_PWM_HANDLE);
    }
  }

  /* End of Terminate for MATLABSystem: '<S2>/PWM' */

  /* Terminate for MATLABSystem: '<S2>/Digital Output1' */
  if (!RotationTesting_DW.obj_ib.matlabCodegenIsDeleted) {
    RotationTesting_DW.obj_ib.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<S2>/Digital Output1' */

  /* Terminate for MATLABSystem: '<S2>/Digital Output3' */
  if (!RotationTesting_DW.obj_i.matlabCodegenIsDeleted) {
    RotationTesting_DW.obj_i.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<S2>/Digital Output3' */

  /* Terminate for MATLABSystem: '<S2>/PWM1' */
  obj_0 = &RotationTesting_DW.obj_k;
  if (!RotationTesting_DW.obj_k.matlabCodegenIsDeleted) {
    RotationTesting_DW.obj_k.matlabCodegenIsDeleted = true;
    if ((RotationTesting_DW.obj_k.isInitialized == 1) &&
        RotationTesting_DW.obj_k.isSetupComplete) {
      obj_0->PWMDriverObj.MW_PWM_HANDLE = MW_PWM_GetHandle(10U);
      MW_PWM_SetDutyCycle(RotationTesting_DW.obj_k.PWMDriverObj.MW_PWM_HANDLE,
                          0.0);
      obj_0->PWMDriverObj.MW_PWM_HANDLE = MW_PWM_GetHandle(10U);
      MW_PWM_Close(RotationTesting_DW.obj_k.PWMDriverObj.MW_PWM_HANDLE);
    }
  }

  /* End of Terminate for MATLABSystem: '<S2>/PWM1' */
}
